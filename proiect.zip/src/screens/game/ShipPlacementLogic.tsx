export const validateShipPlacement = (shipType: string, position: number, orientation: string, table: boolean[]): boolean => {
    return true; 
};

export const placeShipOnTable = (shipType: string, position: number, orientation: string, table: boolean[]): boolean[] => {
    return table; 
};
