import { NavigationProp, useNavigation } from "@react-navigation/native"
import { useAuth } from "../../hooks/authContext"
import { Text } from "react-native"

const TableScreen = () => {
    return <Text>Game</Text>
}

export default TableScreen